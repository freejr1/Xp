#!/bin/bash

echo "🤖 Iniciando Bot Free Fire Automático..."
echo "📦 Verificando dependências..."

# Instala dependências se necessário
pip3 install -r requirements.txt

echo "🚀 Iniciando bot..."
python3 bot.py

